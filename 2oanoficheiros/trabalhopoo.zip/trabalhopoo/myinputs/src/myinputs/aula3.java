package myinputs;

import java.util.Scanner;

public class aula3 {
	public static void main(String[] args) {
		System.out.println("Introduza uma String:");
		double s = Ler.umDouble();
		System.out.print("A string que introduziu foi: " + s);
		}
	}

class ler3int{
	public static void main (String[] args) {
		
	System.out.println("Dá me três números");
	int a = Ler.umInt();
	int b = Ler.umInt();
	int c = Ler.umInt();
		
	int maior = (a > b) ? (a > c ? a : c) : (b > c ? b : c);

	// Imprime o maior valor
	System.out.println("O maior número é " + maior);
	}
}		


 class SomaComFor {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o valor de p (início): ");
        int p = scanner.nextInt();
        
        System.out.print("Digite o valor de u (fim), tal que u >= p: ");
        int u = scanner.nextInt();

        if (p > u) {
            System.out.println("Erro: p deve ser menor ou igual a u.");
        } else {
            int soma = 0;

            for (int i = p; i <= u; i++) {
                soma += i; 
            }

            System.out.println("A soma dos números de " + p + " até " + u + " é: " + soma);
        }

        scanner.close();
    }
}
